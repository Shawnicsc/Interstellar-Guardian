<template>
  <footer class="footer">
    <div class="container">
      <nav>
        <ul>
          <li>
            <a href="http://blog-shawni.top"> Blog </a>
          </li>
        </ul>
      </nav>
      <div class="copyright text-center">
        &copy; {{ new Date().getFullYear() }}
        <a href="https://github.com/Shawnicsc" target="_blank"
          >Shawn i</a
        >, made with <i class="fa fa-heart heart"></i> for a better future
      </div>
    </div>
  </footer>
</template>
<script>
export default {};
</script>
<style></style>
