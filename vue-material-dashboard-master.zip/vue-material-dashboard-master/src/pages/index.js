// Cards
import UserCard from "../pages/UserProfile/UserCard.vue";


export { UserCard };
