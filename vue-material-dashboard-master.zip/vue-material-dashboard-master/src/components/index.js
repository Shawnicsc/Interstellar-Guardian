
// Tables

import SimpleTable from "./Tables/SimpleTable.vue";

export {
  SimpleTable,
};
